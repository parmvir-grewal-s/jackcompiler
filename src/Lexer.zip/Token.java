import javax.sound.sampled.Line;
import java.io.*;
import java.util.Arrays;
import java.util.List;

public class Token {
    public static void main(String[] args) throws IOException {
        Lexer lex = new Lexer();
        lex.Init(args[0]);
        int line = lex.GetLineNum();
        Token token = lex.GetNextToken();
        System.out.println(token.Type + " " + token.Lexeme + " " + lex.GetLineNum());
        while (token.Type != TokenTypes.EOF){
            token = lex.GetNextToken();
            System.out.println(token.Type + " " + token.Lexeme + " " + lex.GetLineNum());
        }
        lex.CloseFile();
    }

    public enum TokenTypes {KeyW, Identifier, TypeNumber, TypeBool, EOF, Symbol, StringLiteral}

    public String Lexeme;
    public TokenTypes Type;

    public Token(){
        Lexeme = "";
    }

}

class Lexer {
    private RandomAccessFile fr;
    private int LineNum; //Keeps track of current line number

    //Used to check if the Lexeme holds a keyword.
    public List<String> Keywords = Arrays.asList("class", "method", "function", "constructor", "var",
            "static", "field", "let", "do", "if", "else", "while", "return", "this", "void");

    public List<String> Symbols = Arrays.asList("{", "}", "(", ")", "[", "]", ".", ",", ";", "+", "-",
            "*", "/", "&", "|", "<", ">", "=", "~");

    public boolean Init(String file_name){
        File temp = new File(file_name);
        if(!temp.exists()){
            System.err.println("File " + file_name + " does not exist");
            return false;
        }

        try {
            fr = new RandomAccessFile(file_name, "r");
        } catch (FileNotFoundException e) {
            System.err.println("Could not open file " + file_name);
            return false;
        }
        LineNum = 1;
        return true;
    }

    public int GetLineNum(){
        return LineNum;
    }

    public void CloseFile() throws IOException {
        fr.close();
    }

    private int Peek() throws IOException{
        long pos = fr.getFilePointer();
        int current = fr.read();
        fr.seek(pos);
        return current;
    }

    public Token GetNextToken() throws IOException {

        Token token = new Token();
        int c;

        while(true){
            c = Peek();

            if (c == -1){
                c = fr.read();
                token.Type = Token.TokenTypes.EOF;
                return token;
            }

            //If "/" is detected, this could be the start of a comment
            if (c == '/'){
                c = fr.read();
                int p = Peek();
                if (p == '/'){
                    c = fr.read();
                    while (c != '\n'){
                        c = fr.read();
                        c = Peek();
                    }
                }

                else if (p == '*'){
                    c = fr.read();
                    //Read the first / and THEN the *
                    c = fr.read();
                    p = Peek();
                    while (c != '*' || p != '/'){
                        if (c == '\n'){
                            LineNum++;
                        }
                        if (c == -1){
                            break;
                        }
                        c = fr.read();
                        p = Peek();
                    }
                    c = fr.read();
                    c = Peek();
                }

            }


            //If a String is detected, store the literal without double quotes
            if (c == '"'){
                token.Type = Token.TokenTypes.StringLiteral;
                c = fr.read();
                //Skips quote
                c = fr.read();
                while (c != '"' && c != -1){
                    token.Lexeme += (char)c;
                    c = fr.read();
                }
                return token;
            }


            //If token starts with a letter/underscore, then its an Identifier
            //or a KeyW
            if (Character.isLetter((char)c) || c == '_'){

                while ((c != -1) && (Character.isLetter((char)c)) || Character.isDigit((char)c)){
                    c = fr.read();
                    token.Lexeme += (char)c;
                    c = Peek();

                }
                for(int i = 0; i < Keywords.size(); i++){
                    if(Keywords.get(i).equals(token.Lexeme)){
                        token.Type = Token.TokenTypes.KeyW;
                        return token;
                    }
                }
                if (token.Lexeme.equals("true") || token.Lexeme.equals("false")){
                    token.Type = Token.TokenTypes.TypeBool;
                    return token;
                }
                token.Type = Token.TokenTypes.Identifier;
                return token;
            }

            if (Character.isDigit((char)c)){
                c = fr.read();
                while ((c != -1) && Character.isDigit((char)c)){
                    token.Lexeme += (char)c;
                    c = fr.read();
                }

                token.Type = Token.TokenTypes.TypeNumber;
                return token;
            }

            if(!Character.isWhitespace((char)c)){
                c = fr.read();
                token.Lexeme += (char)c;
                token.Type = Token.TokenTypes.Symbol;
                return token;
            }



            while (c != -1 && Character.isWhitespace((char)c)){

                if(c =='\r' || c == '\n'){
                    LineNum++;
                }
                c = fr.read();
                c = Peek();

            }
        }


    }

    public Token PeekNextToken() throws IOException{
        long pos = fr.getFilePointer();
        Token peek = GetNextToken();
        fr.seek(pos);
        return peek;
    }
}
